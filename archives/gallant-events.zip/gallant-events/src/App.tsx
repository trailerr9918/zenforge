import { useState, useEffect } from 'react';
import { Phone, MapPin, Clock, Star, ChevronDown, Menu, X, Instagram, Facebook, Twitter, Mail, Calendar, Users, Wine, Music, Camera, Crown } from 'lucide-react';

// Custom Icons
const CrownIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 1L9 9L1 8L6 14L4 22H20L18 14L23 8L15 9L12 1Z" />
  </svg>
);

// Navbar Component
const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Venues', href: '#venues' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
      isScrolled ? 'bg-[#1A1A1A]/95 backdrop-blur-md shadow-2xl' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a href="#home" className="flex items-center gap-3 group">
            <div className="relative">
              <CrownIcon className="w-10 h-10 text-[#C9A96E] group-hover:scale-110 transition-transform duration-300" />
              <div className="absolute inset-0 bg-[#C9A96E] blur-xl opacity-30 group-hover:opacity-50 transition-opacity"></div>
            </div>
            <div className="flex flex-col">
              <span className="font-display text-2xl font-bold text-white tracking-wider">GALLANT</span>
              <span className="font-elegant text-xs tracking-[0.3em] text-[#C9A96E] uppercase">Events Centre</span>
            </div>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="relative text-white/80 hover:text-[#C9A96E] font-medium tracking-wide transition-colors duration-300 group"
              >
                {link.name}
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#C9A96E] transition-all duration-300 group-hover:w-full"></span>
              </a>
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden lg:flex items-center gap-4">
            <a
              href="tel:08023420405"
              className="flex items-center gap-2 text-[#C9A96E] hover:text-white transition-colors duration-300"
            >
              <Phone className="w-4 h-4" />
              <span className="font-medium">0802 342 0405</span>
            </a>
            <a
              href="#contact"
              className="px-6 py-2.5 bg-gradient-to-r from-[#C9A96E] to-[#E8D4A8] text-[#1A1A1A] font-semibold rounded-full hover:shadow-lg hover:shadow-[#C9A96E]/30 transition-all duration-300 transform hover:scale-105"
            >
              Book Now
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden text-white p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        <div className={`lg:hidden overflow-hidden transition-all duration-300 ${
          isMobileMenuOpen ? 'max-h-96 mt-4' : 'max-h-0'
        }`}>
          <div className="bg-[#1A1A1A]/95 backdrop-blur-md rounded-2xl p-6 space-y-4">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="block text-white/80 hover:text-[#C9A96E] font-medium py-2 transition-colors duration-300"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <a
              href="#contact"
              className="block text-center px-6 py-3 bg-gradient-to-r from-[#C9A96E] to-[#E8D4A8] text-[#1A1A1A] font-semibold rounded-full"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Book Now
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
};

// Hero Section
const HeroSection = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background with overlay */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-b from-[#1A1A1A]/70 via-[#1A1A1A]/50 to-[#1A1A1A]/80 z-10"></div>
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1519167758481-83f550bb49b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80')`,
          }}
        ></div>
        {/* Animated gold particles */}
        <div className="absolute inset-0 overflow-hidden z-20">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-[#C9A96E] rounded-full animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${3 + Math.random() * 2}s`,
                opacity: 0.3 + Math.random() * 0.5,
              }}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="relative z-30 text-center px-6 max-w-5xl mx-auto">
        {/* Decorative top element */}
        <div className="flex items-center justify-center gap-4 mb-8">
          <div className="w-20 h-[1px] bg-gradient-to-r from-transparent to-[#C9A96E]"></div>
          <CrownIcon className="w-8 h-8 text-[#C9A96E]" />
          <div className="w-20 h-[1px] bg-gradient-to-l from-transparent to-[#C9A96E]"></div>
        </div>

        <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 tracking-tight">
          Where <span className="text-[#C9A96E]">Elegance</span> Meets
          <br />Celebration
        </h1>

        <p className="font-elegant text-xl md:text-2xl text-white/80 mb-10 max-w-2xl mx-auto leading-relaxed">
          Lagos' premier events destination, where every moment becomes a masterpiece
          and every celebration transforms into an unforgettable memory
        </p>

        {/* Rating badge */}
        <div className="flex items-center justify-center gap-3 mb-12">
          <div className="flex items-center gap-1 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
            <Star className="w-5 h-5 text-[#C9A96E] fill-[#C9A96E]" />
            <span className="text-white font-bold">4.2</span>
            <span className="text-white/60 text-sm">(267 reviews)</span>
          </div>
          <span className="text-white/40">|</span>
          <span className="text-white/80 text-sm">Event Venue in Nigeria</span>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="#contact"
            className="group px-10 py-4 bg-gradient-to-r from-[#C9A96E] to-[#E8D4A8] text-[#1A1A1A] font-bold rounded-full text-lg hover:shadow-2xl hover:shadow-[#C9A96E]/40 transition-all duration-500 transform hover:scale-105 flex items-center gap-3"
          >
            <Calendar className="w-5 h-5" />
            Book Your Event
            <ChevronDown className="w-5 h-5 animate-bounce" />
          </a>
          <a
            href="#venues"
            className="px-10 py-4 border-2 border-[#C9A96E] text-[#C9A96E] font-semibold rounded-full text-lg hover:bg-[#C9A96E] hover:text-[#1A1A1A] transition-all duration-300"
          >
            Explore Venues
          </a>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
          <ChevronDown className="w-8 h-8 text-[#C9A96E]/60" />
        </div>
      </div>

      {/* Side decorations */}
      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-40 bg-gradient-to-b from-transparent via-[#C9A96E] to-transparent hidden lg:block"></div>
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-40 bg-gradient-to-b from-transparent via-[#C9A96E] to-transparent hidden lg:block"></div>
    </section>
  );
};

// About Section
const AboutSection = () => {
  return (
    <section id="about" className="py-24 bg-[#FAF8F5] relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#C9A96E]/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#C9A96E]/5 rounded-full blur-3xl"></div>

      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image Grid */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="img-zoom rounded-2xl overflow-hidden shadow-xl">
                  <img
                    src="https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                    alt="Elegant ballroom"
                    className="w-full h-48 object-cover"
                  />
                </div>
                <div className="img-zoom rounded-2xl overflow-hidden shadow-xl">
                  <img
                    src="https://images.unsplash.com/photo-1505236858219-7749d6ef1706?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                    alt="Wedding decoration"
                    className="w-full h-64 object-cover"
                  />
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="img-zoom rounded-2xl overflow-hidden shadow-xl">
                  <img
                    src="https://images.unsplash.com/photo-1511795409834-ef04bbd61622?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                    alt="Champagne toast"
                    className="w-full h-64 object-cover"
                  />
                </div>
                <div className="img-zoom rounded-2xl overflow-hidden shadow-xl">
                  <img
                    src="https://images.unsplash.com/photo-1478146896983-b58710e3e1e0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                    alt="Garden event"
                    className="w-full h-48 object-cover"
                  />
                </div>
              </div>
            </div>
            {/* Decorative element */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 border-2 border-[#C9A96E] rounded-2xl -z-10"></div>
            <div className="absolute -top-6 -left-6 w-24 h-24 bg-[#C9A96E]/10 rounded-2xl -z-10"></div>
          </div>

          {/* Content */}
          <div className="lg:pl-8">
            <div className="inline-flex items-center gap-3 mb-6">
              <div className="decorative-line"></div>
              <span className="text-[#C9A96E] font-medium tracking-widest uppercase text-sm">Our Story</span>
            </div>

            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#1A1A1A] mb-6 leading-tight">
              Crafting Unforgettable
              <span className="block text-[#C9A96E]">Moments Since 2010</span>
            </h2>

            <p className="font-elegant text-xl text-[#1A1A1A]/70 mb-8 leading-relaxed">
              Gallant Events Centre stands as Lagos' most prestigious event destination,
              where luxury meets hospitality in perfect harmony. Our commitment to excellence
              has made us the preferred choice for those who demand nothing but the best.
            </p>

            <div className="grid grid-cols-2 gap-6 mb-10">
              {[
                { number: '15+', label: 'Years Experience' },
                { number: '500+', label: 'Events Hosted' },
                { number: '500+', label: 'Happy Clients' },
                { number: '4.8', label: 'Average Rating' },
              ].map((stat, index) => (
                <div
                  key={index}
                  className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300"
                >
                  <div className="font-display text-3xl font-bold text-[#C9A96E] mb-1">{stat.number}</div>
                  <div className="text-[#1A1A1A]/60 text-sm">{stat.label}</div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-[#C9A96E] flex items-center justify-center">
                <CrownIcon className="w-8 h-8 text-white" />
              </div>
              <div>
                <p className="font-semibold text-[#1A1A1A]">Premium Service</p>
                <p className="text-[#1A1A1A]/60 text-sm">World-class event management</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// Venues Section
const VenuesSection = () => {
  const venues = [
    {
      name: 'Grand Ballroom',
      capacity: '500 Guests',
      description: 'Our flagship venue featuring soaring ceilings, crystal chandeliers, and a state-of-the-art sound system.',
      image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      features: ['Air Conditioned', 'Sound System', 'Dance Floor', 'Stage'],
    },
    {
      name: 'Crystal Garden',
      capacity: '300 Guests',
      description: 'An enchanting outdoor space surrounded by lush gardens and twinkling lights, perfect for evening celebrations.',
      image: 'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      features: ['Garden View', 'Natural Light', 'String Lights', 'Bar'],
    },
    {
      name: 'Executive Lounge',
      capacity: '150 Guests',
      description: 'Intimate and sophisticated space ideal for corporate events, workshops, and intimate gatherings.',
      image: 'https://images.unsplash.com/photo-1505236858219-7749d6ef1706?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
      features: ['Private Bar', 'Lounge Seating', 'AV Equipment', 'Breakout Rooms'],
    },
  ];

  return (
    <section id="venues" className="py-24 bg-[#1A1A1A] relative overflow-hidden">
      {/* Background texture */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23C9A96E' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="decorative-line"></div>
            <span className="text-[#C9A96E] font-medium tracking-widest uppercase text-sm">Our Venues</span>
            <div className="decorative-line"></div>
          </div>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-6">
            Exquisite Spaces for
            <span className="block text-[#C9A96E]">Every Occasion</span>
          </h2>
          <p className="font-elegant text-xl text-white/60 max-w-2xl mx-auto">
            Each venue is meticulously designed to create the perfect ambiance for your special day
          </p>
        </div>

        {/* Venue Cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {venues.map((venue, index) => (
            <div
              key={index}
              className="group relative bg-[#FAF8F5] rounded-3xl overflow-hidden shadow-2xl hover:shadow-[#C9A96E]/20 transition-all duration-500"
            >
              {/* Image */}
              <div className="relative h-72 overflow-hidden">
                <img
                  src={venue.image}
                  alt={venue.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A]/80 via-transparent to-transparent"></div>
                {/* Badge */}
                <div className="absolute top-4 right-4 bg-[#C9A96E] px-4 py-2 rounded-full">
                  <span className="text-[#1A1A1A] font-semibold text-sm">{venue.capacity}</span>
                </div>
              </div>

              {/* Content */}
              <div className="p-8">
                <h3 className="font-display text-2xl font-bold text-[#1A1A1A] mb-3">{venue.name}</h3>
                <p className="text-[#1A1A1A]/60 mb-6 leading-relaxed">{venue.description}</p>

                {/* Features */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {venue.features.map((feature, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 bg-[#C9A96E]/10 text-[#C9A96E] text-sm rounded-full"
                    >
                      {feature}
                    </span>
                  ))}
                </div>

                {/* CTA */}
                <a
                  href="#contact"
                  className="inline-flex items-center gap-2 text-[#C9A96E] font-semibold hover:gap-4 transition-all duration-300"
                >
                  Book This Venue
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Services Grid */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { icon: Camera, label: 'Professional Photography' },
            { icon: Music, label: 'Live Entertainment' },
            { icon: Wine, label: 'Premium Catering' },
            { icon: Users, label: 'Event Planning' },
          ].map((service, index) => (
            <div
              key={index}
              className="text-center group cursor-pointer"
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[#C9A96E]/10 flex items-center justify-center group-hover:bg-[#C9A96E] transition-colors duration-300">
                <service.icon className="w-8 h-8 text-[#C9A96E] group-hover:text-[#1A1A1A] transition-colors duration-300" />
              </div>
              <p className="text-white/80 font-medium">{service.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Gallery Section
const GallerySection = () => {
  const images = [
    'https://images.unsplash.com/photo-1519741497674-611481863552?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1478146896983-b58710e3e1e0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1505236858219-7749d6ef1706?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1540575467063-178a50c2df87?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  ];

  return (
    <section id="gallery" className="py-24 bg-[#FAF8F5] relative">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="decorative-line"></div>
            <span className="text-[#C9A96E] font-medium tracking-widest uppercase text-sm">Gallery</span>
            <div className="decorative-line"></div>
          </div>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-[#1A1A1A] mb-6">
            Moments We've <span className="text-[#C9A96E]">Created</span>
          </h2>
          <p className="font-elegant text-xl text-[#1A1A1A]/60 max-w-2xl mx-auto">
            A glimpse into the magical moments we've crafted for our valued clients
          </p>
        </div>

        {/* Masonry Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {images.map((image, index) => (
            <div
              key={index}
              className={`img-zoom rounded-2xl overflow-hidden shadow-lg ${
                index === 0 ? 'row-span-2' : ''
              } ${index === 3 ? 'md:col-span-2' : ''}`}
            >
              <img
                src={image}
                alt={`Gallery image ${index + 1}`}
                className="w-full h-full object-cover"
                style={{ minHeight: index === 0 ? '500px' : '250px' }}
              />
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <a
            href="#contact"
            className="inline-flex items-center gap-2 px-8 py-4 border-2 border-[#C9A96E] text-[#C9A96E] font-semibold rounded-full hover:bg-[#C9A96E] hover:text-[#1A1A1A] transition-all duration-300"
          >
            View All Photos
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
};

// Reviews Section
const ReviewsSection = () => {
  const reviews = [
    {
      name: 'Adaeze Okonkwo',
      event: 'Wedding Reception',
      rating: 5,
      text: 'Gallant Events Centre made our wedding absolutely magical. The attention to detail, the impeccable service, and the stunning venue made our day perfect. Cannot recommend them enough!',
      date: '2 weeks ago',
    },
    {
      name: 'Emeka Nwosu',
      event: 'Corporate Gala',
      rating: 5,
      text: 'We hosted our annual corporate gala here and it exceeded all expectations. The staff was professional, the facilities were top-notch, and our guests were thoroughly impressed.',
      date: '1 month ago',
    },
    {
      name: 'Funke Adeleke',
      event: 'Birthday Celebration',
      rating: 4,
      text: 'The birthday celebration for my mother was everything we dreamed of. The team went above and beyond to create a memorable experience. The venue is simply breathtaking.',
      date: '3 weeks ago',
    },
  ];

  return (
    <section id="reviews" className="py-24 bg-[#1A1A1A] relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#C9A96E]/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-[#C9A96E]/5 rounded-full blur-3xl"></div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="decorative-line"></div>
            <span className="text-[#C9A96E] font-medium tracking-widest uppercase text-sm">Testimonials</span>
            <div className="decorative-line"></div>
          </div>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-6">
            What Our <span className="text-[#C9A96E]">Clients</span> Say
          </h2>
          <div className="flex items-center justify-center gap-4">
            <div className="flex items-center gap-2 bg-[#C9A96E] px-4 py-2 rounded-full">
              <Star className="w-5 h-5 text-[#1A1A1A] fill-[#1A1A1A]" />
              <span className="font-bold text-[#1A1A1A]">4.2</span>
            </div>
            <span className="text-white/60">Based on 267 reviews</span>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <div
              key={index}
              className="bg-[#FAF8F5]/5 backdrop-blur-sm rounded-3xl p-8 border border-[#C9A96E]/20 hover:border-[#C9A96E]/40 transition-colors duration-300"
            >
              {/* Rating */}
              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${i < review.rating ? 'text-[#C9A96E] fill-[#C9A96E]' : 'text-white/20'}`}
                  />
                ))}
              </div>

              {/* Text */}
              <p className="font-elegant text-lg text-white/80 mb-6 leading-relaxed italic">
                "{review.text}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#C9A96E] flex items-center justify-center">
                  <span className="font-bold text-[#1A1A1A]">{review.name.charAt(0)}</span>
                </div>
                <div>
                  <p className="font-semibold text-white">{review.name}</p>
                  <p className="text-[#C9A96E] text-sm">{review.event}</p>
                </div>
              </div>

              {/* Date */}
              <p className="text-white/40 text-sm mt-4">{review.date}</p>
            </div>
          ))}
        </div>

        {/* Google Badge */}
        <div className="text-center mt-12">
          <div className="inline-flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-full px-6 py-3">
            <span className="text-white/60">Powered by</span>
            <span className="text-white font-semibold">Google</span>
            <Star className="w-5 h-5 text-[#C9A96E] fill-[#C9A96E]" />
          </div>
        </div>
      </div>
    </section>
  );
};

// Contact Section
const ContactSection = () => {
  return (
    <section id="contact" className="py-24 bg-[#FAF8F5] relative">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="decorative-line"></div>
            <span className="text-[#C9A96E] font-medium tracking-widest uppercase text-sm">Contact Us</span>
            <div className="decorative-line"></div>
          </div>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-[#1A1A1A] mb-6">
            Begin Your <span className="text-[#C9A96E]">Journey</span>
          </h2>
          <p className="font-elegant text-xl text-[#1A1A1A]/60 max-w-2xl mx-auto">
            Ready to create your unforgettable event? Let's discuss how we can make your vision a reality.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-2xl">
            <h3 className="font-display text-2xl font-bold text-[#1A1A1A] mb-8">Send Us a Message</h3>

            <form className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[#1A1A1A]/60 text-sm mb-2">Full Name</label>
                  <input
                    type="text"
                    placeholder="John Doe"
                    className="w-full px-4 py-3 rounded-xl border border-[#1A1A1A]/10 focus:border-[#C9A96E] focus:ring-2 focus:ring-[#C9A96E]/20 outline-none transition-all duration-300"
                  />
                </div>
                <div>
                  <label className="block text-[#1A1A1A]/60 text-sm mb-2">Email Address</label>
                  <input
                    type="email"
                    placeholder="john@example.com"
                    className="w-full px-4 py-3 rounded-xl border border-[#1A1A1A]/10 focus:border-[#C9A96E] focus:ring-2 focus:ring-[#C9A96E]/20 outline-none transition-all duration-300"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#1A1A1A]/60 text-sm mb-2">Phone Number</label>
                <input
                  type="tel"
                  placeholder="+234 800 000 0000"
                  className="w-full px-4 py-3 rounded-xl border border-[#1A1A1A]/10 focus:border-[#C9A96E] focus:ring-2 focus:ring-[#C9A96E]/20 outline-none transition-all duration-300"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[#1A1A1A]/60 text-sm mb-2">Event Type</label>
                  <select className="w-full px-4 py-3 rounded-xl border border-[#1A1A1A]/10 focus:border-[#C9A96E] focus:ring-2 focus:ring-[#C9A96E]/20 outline-none transition-all duration-300 bg-white">
                    <option>Select Event Type</option>
                    <option>Wedding</option>
                    <option>Corporate Event</option>
                    <option>Birthday Party</option>
                    <option>Conference</option>
                    <option>Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[#1A1A1A]/60 text-sm mb-2">Expected Date</label>
                  <input
                    type="date"
                    className="w-full px-4 py-3 rounded-xl border border-[#1A1A1A]/10 focus:border-[#C9A96E] focus:ring-2 focus:ring-[#C9A96E]/20 outline-none transition-all duration-300"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#1A1A1A]/60 text-sm mb-2">Your Message</label>
                <textarea
                  rows={4}
                  placeholder="Tell us about your event vision..."
                  className="w-full px-4 py-3 rounded-xl border border-[#1A1A1A]/10 focus:border-[#C9A96E] focus:ring-2 focus:ring-[#C9A96E]/20 outline-none transition-all duration-300 resize-none"
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full py-4 bg-gradient-to-r from-[#C9A96E] to-[#E8D4A8] text-[#1A1A1A] font-bold rounded-xl hover:shadow-lg hover:shadow-[#C9A96E]/30 transition-all duration-300 transform hover:scale-[1.02] flex items-center justify-center gap-2"
              >
                <Calendar className="w-5 h-5" />
                Request a Callback
              </button>
            </form>
          </div>

          {/* Contact Info & Map */}
          <div className="space-y-8">
            {/* Contact Info Cards */}
            <div className="grid gap-6">
              {[
                { icon: MapPin, title: 'Visit Us', content: 'Jumat Olukoya Street, Ojota, Ikeja 105102, Lagos, Nigeria', link: 'https://maps.google.com' },
                { icon: Phone, title: 'Call Us', content: '0802 342 0405', link: 'tel:08023420405' },
                { icon: Clock, title: 'Opening Hours', content: 'Mon - Sat: 8:00 AM - 6:00 PM', link: null },
                { icon: Mail, title: 'Email Us', content: 'info@gallantevents.com', link: 'mailto:info@gallantevents.com' },
              ].map((item, index) => (
                <div key={index} className="bg-white rounded-2xl p-6 shadow-lg flex items-start gap-4 hover:shadow-xl transition-shadow duration-300">
                  <div className="w-12 h-12 rounded-full bg-[#C9A96E]/10 flex items-center justify-center flex-shrink-0">
                    <item.icon className="w-6 h-6 text-[#C9A96E]" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-[#1A1A1A] mb-1">{item.title}</h4>
                    {item.link ? (
                      <a href={item.link} className="text-[#1A1A1A]/60 hover:text-[#C9A96E] transition-colors">
                        {item.content}
                      </a>
                    ) : (
                      <p className="text-[#1A1A1A]/60">{item.content}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Map */}
            <div className="rounded-2xl overflow-hidden shadow-xl h-64">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3963.3!2d3.38!3d6.62!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2sOjota%2C%20Ikeja!5e0!3m2!1sen!2sng!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Gallant Events Centre Location"
              ></iframe>
            </div>

            {/* Quick Actions */}
            <div className="flex gap-4">
              <a
                href="tel:08023420405"
                className="flex-1 py-4 bg-gradient-to-r from-[#C9A96E] to-[#E8D4A8] text-[#1A1A1A] font-bold rounded-xl hover:shadow-lg hover:shadow-[#C9A96E]/30 transition-all duration-300 text-center flex items-center justify-center gap-2"
              >
                <Phone className="w-5 h-5" />
                Call Now
              </a>
              <a
                href="https://wa.me/2348023420405"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-4 bg-[#25D366] text-white font-bold rounded-xl hover:shadow-lg hover:shadow-[#25D366]/30 transition-all duration-300 text-center flex items-center justify-center gap-2"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// Footer
const Footer = () => {
  return (
    <footer className="bg-[#1A1A1A] pt-20 pb-8 relative overflow-hidden">
      {/* Top decorative border */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#C9A96E] to-transparent"></div>

      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-3 mb-6">
              <CrownIcon className="w-10 h-10 text-[#C9A96E]" />
              <div className="flex flex-col">
                <span className="font-display text-2xl font-bold text-white tracking-wider">GALLANT</span>
                <span className="font-elegant text-xs tracking-[0.3em] text-[#C9A96E] uppercase">Events Centre</span>
              </div>
            </div>
            <p className="font-elegant text-white/60 mb-6 leading-relaxed">
              Lagos' premier destination for extraordinary events. Where every celebration becomes an unforgettable masterpiece.
            </p>
            <div className="flex items-center gap-4">
              {[Instagram, Facebook, Twitter].map((Icon, index) => (
                <a
                  key={index}
                  href="#"
                  className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#C9A96E] transition-colors duration-300 group"
                >
                  <Icon className="w-5 h-5 text-white/60 group-hover:text-[#1A1A1A]" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display text-lg font-semibold text-white mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {['Home', 'About', 'Venues', 'Gallery', 'Reviews', 'Contact'].map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase()}`} className="text-white/60 hover:text-[#C9A96E] transition-colors duration-300">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-display text-lg font-semibold text-white mb-6">Our Services</h4>
            <ul className="space-y-3">
              {['Wedding Planning', 'Corporate Events', 'Birthday Parties', 'Conferences', 'Catering Services', 'Photography'].map((service) => (
                <li key={service}>
                  <span className="text-white/60">{service}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display text-lg font-semibold text-white mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#C9A96E] flex-shrink-0 mt-1" />
                <span className="text-white/60">Jumat Olukoya Street, Ojota, Ikeja 105102, Lagos</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-[#C9A96E]" />
                <a href="tel:08023420405" className="text-white/60 hover:text-[#C9A96E] transition-colors">0802 342 0405</a>
              </li>
              <li className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-[#C9A96E]" />
                <span className="text-white/60">Mon - Sat: 8AM - 6PM</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-white/40 text-sm text-center md:text-left">
              © 2024 Gallant Events Centre. All rights reserved.
            </p>
            <div className="flex items-center gap-6 text-sm">
              <a href="#" className="text-white/40 hover:text-[#C9A96E] transition-colors">Privacy Policy</a>
              <a href="#" className="text-white/40 hover:text-[#C9A96E] transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </div>

      {/* Back to Top Button */}
      <a
        href="#home"
        className="fixed bottom-8 right-8 w-12 h-12 bg-[#C9A96E] rounded-full flex items-center justify-center shadow-lg hover:shadow-xl hover:scale-110 transition-all duration-300 z-50"
      >
        <ChevronDown className="w-6 h-6 text-[#1A1A1A] rotate-180" />
      </a>
    </footer>
  );
};

// Main App Component
function App() {
  return (
    <div className="min-h-screen bg-[#FAF8F5]">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <VenuesSection />
      <GallerySection />
      <ReviewsSection />
      <ContactSection />
      <Footer />
    </div>
  );
}

export default App;